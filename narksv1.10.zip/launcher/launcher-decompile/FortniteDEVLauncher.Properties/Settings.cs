using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace FortniteDEVLauncher.Properties
{
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.5.0.0")]
	internal sealed class Settings : ApplicationSettingsBase
	{
		private static Settings defaultInstance;

		public static Settings Default => defaultInstance;

		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		[UserScopedSetting]
		public string Path
		{
			get
			{
				return (string)((SettingsBase)this).get_Item("Path");
			}
			set
			{
				((SettingsBase)this).set_Item("Path", (object)value);
			}
		}

		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		[UserScopedSetting]
		public string Username
		{
			get
			{
				return (string)((SettingsBase)this).get_Item("Username");
			}
			set
			{
				((SettingsBase)this).set_Item("Username", (object)value);
			}
		}

		static Settings()
		{
			defaultInstance = (Settings)(object)SettingsBase.Synchronized((SettingsBase)(object)new Settings());
		}

		public Settings()
			: this()
		{
		}
	}
}
