# narkslauncher
Private fortnite launcher

- ✔️ Permet d'avoir toute les emote
- ✔️ Permet d'avoir tout les skin
- ✔️ Mis à jour tout les jours
- ✔️ Panel inclus
- ✔️ Gratuit

- ❌ Permet de jouer dans une map
- ❌ Ajout d'ami

# API'S

Nous utilisons :
- <a href="https://fortnite-api.com/" rel="nofollow">Fortnite-API</a> créer par <a href="https://discordapp.com/users/373913699943186432" rel="nofollow">Officer</a>

- <a href="https://nitestats.com/" rel="nofollow">NiteStats API</a> créer par <a href="https://discordapp.com/users/249459068341583872" rel="nofollow">VastBlast</a>

# AUTRES

- Nous utilisions fortnite.dev pour le launcher

- Thanks to NeoNite.dev
