FR //
Pour utilisez le launcher , veuillez suivre ce programme :
1) cliquez sur installfirst et attendez que l'installateur de nodejs s'ouvre.
2) une fois que l'installateur de nodejs s'ouvre, cliquer sur suivant et installer le.
3) cliquez sur installsecond et attendez que tout s'installe.
4) ensuite vous pouvez supprimer les 2 install .
5) Et voila , cliquez sur start , et le launcher va se lancez , il faudra mettre son pseudo .
NOTE: Si vous utilisez ce pseudo pour la première fois sur le launcher , il vous faudra le redémarrer une deuxième fois.

EN //
To use the launcher, please follow this program:
1) click on installfirst and wait for the nodejs installer to open.
2) once the nodejs installer opens, click on next and install it.
3) click on installsecond and wait for everything to install.
4) then you can remove the 2 install.
5) And voila, click on start, and the launcher will start, you will have to put his nickname.
NOTE: If you are using this nickname for the first time on the launcher, you will need to restart it a second time.