using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace FortniteDEVLauncher
{
	internal class Program
	{
		private static Process _clientProcess;

		private static byte _clientAnticheat;

		[STAThread]
		private static void Main(string[] args)
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run((Form)(object)new GUI());
		}

		private static bool Routine(int dwCtrlType)
		{
			if (dwCtrlType == 2 && !_clientProcess.get_HasExited())
			{
				_clientProcess.Kill();
			}
			return false;
		}
	}
}
