using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace FortniteDEVLauncher
{
	public class Browser : Form
	{
		private IContainer components;

		private WebBrowser webBrowser1;

		public Browser()
			: this()
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Expected O, but got Unknown
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			InitializeComponent();
			IWebDriver val = (IWebDriver)(object)new ChromeDriver();
			val.Navigate().GoToUrl("https://discord.com/oauth2/authorize?client_id=715095607357997096&redirect_uri=http%3A%2F%2F127.0.0.1%3A3003%2Ftoken&response_type=token&scope=identify");
			MessageBox.Show(val.get_PageSource());
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				((IDisposable)components).Dispose();
			}
			((Form)this).Dispose(disposing);
		}

		private void InitializeComponent()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_0039: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0091: Unknown result type (might be due to invalid IL or missing references)
			//IL_009b: Expected O, but got Unknown
			webBrowser1 = (WebBrowser)(object)new WebBrowser();
			((Control)this).SuspendLayout();
			((Control)webBrowser1).set_Dock((DockStyle)5);
			((Control)webBrowser1).set_Location(new Point(0, 0));
			((Control)webBrowser1).set_MinimumSize(new Size(20, 20));
			((Control)webBrowser1).set_Name("webBrowser1");
			webBrowser1.set_ScriptErrorsSuppressed(true);
			((Control)webBrowser1).set_Size(new Size(489, 555));
			((Control)webBrowser1).set_TabIndex(0);
			webBrowser1.set_Url((Uri)(object)new Uri("https://discord.com/oauth2/authorize?client_id=715095607357997096&redirect_uri=http%3A%2F%2F127.0.0.1%3A3003%2Ftoken&response_type=token&scope=identify", (UriKind)1));
		}
	}
}
