namespace FortniteDEVLauncher
{
	internal class Configuration
	{
		internal const string ClientExecutable = "FortniteClient-Win64-Shipping.exe";

		internal const string ClientArguments = "-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal";

		internal const string ClientNative = "Launcher.dll";

		internal const string BEToken = "f7b9gah4h5380d10f721dd6a";

		internal const string EACToken = "10ga222d803bh65851660E3d";
	}
}
