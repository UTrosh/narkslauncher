using FortniteDEVLauncher.Properties;
using MaterialSkin;
using MaterialSkin.Controls;
using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace FortniteDEVLauncher
{
	public class GUI : MaterialForm
	{
		private class Installed
		{
			public class Installation
			{
				public string AppName
				{
					get;
					set;
				}

				public string AppVersion
				{
					get;
					set;
				}

				public string InstallLocation
				{
					get;
					set;
				}
			}

			public Installation[] InstallationList
			{
				get;
				set;
			}
		}

		public const int WM_NCLBUTTONDOWN = 161;

		public const int HT_CAPTION = 2;

		public const int INTERNET_OPTION_SETTINGS_CHANGED = 39;

		public const int INTERNET_OPTION_REFRESH = 37;

		private static readonly string _installedPath;

		private static Process _clientProcess;

		private static byte _clientAnticheat;

		private FolderBrowserDialog folderBrowserDialogBrowse;

		private MaterialTextBox materialTextBox1;

		private MaterialTextBox materialTextBox2;

		private MaterialButton materialButton1;

		private MaterialButton materialButton2;

		private MaterialButton materialButton3;

		private IContainer components;

		static GUI()
		{
			_installedPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Epic\\UnrealEngineLauncher\\LauncherInstalled.dat");
		}

		public GUI()
			: this()
		{
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Expected O, but got Unknown
			InitializeComponent();
			MaterialSkinManager instance = MaterialSkinManager.get_Instance();
			instance.AddFormToManage((MaterialForm)(object)this);
			instance.set_Theme((Themes)1);
			instance.set_ColorScheme((ColorScheme)(object)new ColorScheme((Primary)4367861, (Primary)870305, (Primary)870305, (Accent)4492031, (TextShade)16777215));
			((Control)materialTextBox1).set_Text(Settings.Default.Username);
			((Control)materialTextBox2).set_Text(Settings.Default.Path);
			if (File.Exists(_installedPath))
			{
				Installed.Installation[] installationList = JsonConvert.DeserializeObject<Installed>(File.ReadAllText(_installedPath)).InstallationList;
				Installed.Installation[] array = installationList;
				foreach (Installed.Installation installation in array)
				{
					if (installation.AppName == "Fortnite")
					{
						((Control)materialTextBox2).set_Text(installation.InstallLocation);
					}
				}
			}
			else
			{
				((Control)materialTextBox2).set_Text("Couldn't find Fortnite path, please use the \"...\" button to specify your Fortnite path!");
			}
		}

		[DllImport("wininet.dll")]
		public static extern bool InternetSetOption(IntPtr hInternet, int dwOption, IntPtr lpBuffer, int dwBufferLength);

		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		[DllImport("user32.dll", SetLastError = true)]
		private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out int processId);

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				((IDisposable)components).Dispose();
			}
			((Form)this).Dispose(disposing);
		}

		private void InitializeComponent()
		{
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Expected O, but got Unknown
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			//IL_001b: Expected O, but got Unknown
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0027: Unknown result type (might be due to invalid IL or missing references)
			//IL_0031: Expected O, but got Unknown
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_003c: Expected O, but got Unknown
			//IL_003d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0047: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0080: Unknown result type (might be due to invalid IL or missing references)
			//IL_008a: Expected O, but got Unknown
			//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_0155: Unknown result type (might be due to invalid IL or missing references)
			//IL_015f: Expected O, but got Unknown
			//IL_017c: Unknown result type (might be due to invalid IL or missing references)
			//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0243: Unknown result type (might be due to invalid IL or missing references)
			//IL_0257: Unknown result type (might be due to invalid IL or missing references)
			//IL_028a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0343: Unknown result type (might be due to invalid IL or missing references)
			//IL_0357: Unknown result type (might be due to invalid IL or missing references)
			//IL_0387: Unknown result type (might be due to invalid IL or missing references)
			//IL_0429: Unknown result type (might be due to invalid IL or missing references)
			//IL_0433: Expected O, but got Unknown
			//IL_0440: Unknown result type (might be due to invalid IL or missing references)
			//IL_0454: Unknown result type (might be due to invalid IL or missing references)
			//IL_0484: Unknown result type (might be due to invalid IL or missing references)
			//IL_04f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_0513: Unknown result type (might be due to invalid IL or missing references)
			ComponentResourceManager val = (ComponentResourceManager)(object)new ComponentResourceManager(typeof(GUI));
			folderBrowserDialogBrowse = (FolderBrowserDialog)(object)new FolderBrowserDialog();
			materialTextBox1 = (MaterialTextBox)(object)new MaterialTextBox();
			materialTextBox2 = (MaterialTextBox)(object)new MaterialTextBox();
			materialButton1 = (MaterialButton)(object)new MaterialButton();
			materialButton2 = (MaterialButton)(object)new MaterialButton();
			materialButton3 = (MaterialButton)(object)new MaterialButton();
			((Control)this).SuspendLayout();
			((TextBoxBase)materialTextBox1).set_BorderStyle((BorderStyle)0);
			materialTextBox1.set_Depth(0);
			((Control)materialTextBox1).set_Font((Font)(object)new Font("Microsoft Sans Serif", 12f));
			materialTextBox1.set_Hint("Pseudo");
			((Control)materialTextBox1).set_Location(new Point(35, 96));
			((TextBoxBase)materialTextBox1).set_MaxLength(50);
			materialTextBox1.set_MouseState((MouseState)2);
			((TextBoxBase)materialTextBox1).set_Multiline(false);
			((Control)materialTextBox1).set_Name("materialTextBox1");
			((Control)materialTextBox1).set_Size(new Size(215, 50));
			((Control)materialTextBox1).set_TabIndex(3);
			((Control)materialTextBox1).set_Text("Pseudo");
			((Control)materialTextBox1).add_TextChanged((EventHandler)materialTextBox1_TextChanged);
			((TextBoxBase)materialTextBox2).set_BorderStyle((BorderStyle)0);
			materialTextBox2.set_Depth(0);
			((Control)materialTextBox2).set_Font((Font)(object)new Font("Microsoft Sans Serif", 12f));
			materialTextBox2.set_Hint("Direction vers fortnite");
			((Control)materialTextBox2).set_Location(new Point(35, 174));
			((TextBoxBase)materialTextBox2).set_MaxLength(50);
			materialTextBox2.set_MouseState((MouseState)2);
			((TextBoxBase)materialTextBox2).set_Multiline(false);
			((Control)materialTextBox2).set_Name("materialTextBox2");
			((Control)materialTextBox2).set_Size(new Size(264, 50));
			((Control)materialTextBox2).set_TabIndex(4);
			((Control)materialTextBox2).set_Text("Direction vers fortnite");
			((Control)materialButton1).set_AutoSize(false);
			((Button)materialButton1).set_AutoSizeMode((AutoSizeMode)0);
			materialButton1.set_Depth(0);
			materialButton1.set_DrawShadows(true);
			materialButton1.set_HighEmphasis(true);
			materialButton1.set_Icon((Image)null);
			((Control)materialButton1).set_Location(new Point(35, 245));
			((Control)materialButton1).set_Margin(new Padding(4, 6, 4, 6));
			materialButton1.set_MouseState((MouseState)0);
			((Control)materialButton1).set_Name("materialButton1");
			((Control)materialButton1).set_Size(new Size(340, 91));
			((Control)materialButton1).set_TabIndex(5);
			((Control)materialButton1).set_Text("Lancez");
			materialButton1.set_Type((MaterialButtonType)2);
			materialButton1.set_UseAccentColor(false);
			((ButtonBase)materialButton1).set_UseVisualStyleBackColor(true);
			((Control)materialButton1).add_Click((EventHandler)materialButton1_Click);
			((Control)materialButton2).set_AutoSize(false);
			((Button)materialButton2).set_AutoSizeMode((AutoSizeMode)0);
			materialButton2.set_Depth(0);
			materialButton2.set_DrawShadows(true);
			materialButton2.set_HighEmphasis(true);
			materialButton2.set_Icon((Image)null);
			((Control)materialButton2).set_Location(new Point(319, 184));
			((Control)materialButton2).set_Margin(new Padding(4, 6, 4, 6));
			materialButton2.set_MouseState((MouseState)0);
			((Control)materialButton2).set_Name("materialButton2");
			((Control)materialButton2).set_Size(new Size(56, 36));
			((Control)materialButton2).set_TabIndex(6);
			((Control)materialButton2).set_Text("....");
			materialButton2.set_Type((MaterialButtonType)2);
			materialButton2.set_UseAccentColor(false);
			((ButtonBase)materialButton2).set_UseVisualStyleBackColor(true);
			((Control)materialButton2).add_Click((EventHandler)materialButton2_Click);
			((Button)materialButton3).set_AutoSizeMode((AutoSizeMode)0);
			materialButton3.set_Depth(0);
			materialButton3.set_DrawShadows(true);
			materialButton3.set_HighEmphasis(true);
			materialButton3.set_Icon((Image)(object)(Image)((ResourceManager)(object)val).GetObject("materialButton3.Icon"));
			((Control)materialButton3).set_Location(new Point(271, 104));
			((Control)materialButton3).set_Margin(new Padding(4, 6, 4, 6));
			materialButton3.set_MouseState((MouseState)0);
			((Control)materialButton3).set_Name("materialButton3");
			((Control)materialButton3).set_Size(new Size(104, 36));
			((Control)materialButton3).set_TabIndex(7);
			((Control)materialButton3).set_Text("Rejoins nous");
			materialButton3.set_Type((MaterialButtonType)2);
			materialButton3.set_UseAccentColor(false);
			((ButtonBase)materialButton3).set_UseVisualStyleBackColor(true);
			((Control)materialButton3).add_Click((EventHandler)materialButton3_Click_1);
			((ContainerControl)this).set_AutoScaleDimensions(new SizeF(6f, 13f));
			((ContainerControl)this).set_AutoScaleMode((AutoScaleMode)1);
			((Form)this).set_AutoSizeMode((AutoSizeMode)0);
			((Form)this).set_ClientSize(new Size(409, 363));
			((Control)this).get_Controls().Add((Control)(object)materialButton3);
			((Control)this).get_Controls().Add((Control)(object)materialButton2);
			((Control)this).get_Controls().Add((Control)(object)materialButton1);
			((Control)this).get_Controls().Add((Control)(object)materialTextBox2);
			((Control)this).get_Controls().Add((Control)(object)materialTextBox1);
			((Control)this).set_Name("GUI");
			((Control)this).set_Text("NarksLauncher");
			((Form)this).add_Load((EventHandler)GUI_Load);
			((Control)this).ResumeLayout(false);
			((Control)this).PerformLayout();
		}

		private bool IsValidPath(string path)
		{
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			//IL_0045: Unknown result type (might be due to invalid IL or missing references)
			if (new Regex("^[a-zA-Z]:\\\\$").IsMatch(path.Substring(0, 3)))
			{
				string str = new string(Path.GetInvalidPathChars());
				str += ":/?*\"";
				return !new Regex("[" + Regex.Escape(str) + "]").IsMatch(path.Substring(3, path.Length - 3));
			}
			return false;
		}

		private void GUI_Load(object sender, EventArgs e)
		{
			if (Process.GetProcessesByName("Fiddler").Length == 1)
			{
				Application.Exit();
			}
		}

		private void materialTextBox1_TextChanged(object sender, EventArgs e)
		{
		}

		private void materialButton2_Click(object sender, EventArgs e)
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Invalid comparison between Unknown and I4
			if ((int)((CommonDialog)folderBrowserDialogBrowse).ShowDialog() == 1)
			{
				((Control)materialTextBox2).set_Text(folderBrowserDialogBrowse.get_SelectedPath());
			}
		}

		private void materialButton1_Click(object sender, EventArgs e)
		{
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			//IL_003d: Unknown result type (might be due to invalid IL or missing references)
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00be: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
			//IL_0160: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
			//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
			//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
			//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f6: Expected O, but got Unknown
			//IL_01fb: Expected O, but got Unknown
			//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0202: Expected O, but got Unknown
			//IL_0246: Unknown result type (might be due to invalid IL or missing references)
			//IL_024d: Expected O, but got Unknown
			//IL_0281: Unknown result type (might be due to invalid IL or missing references)
			//IL_0288: Expected O, but got Unknown
			//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
			//IL_02e4: Expected O, but got Unknown
			//IL_0330: Unknown result type (might be due to invalid IL or missing references)
			int num = Convert.ToInt32(Console.ReadLine());
			RegistryKey val = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings", true);
			if (!new Regex("^([a-zA-Z0-9])*$").IsMatch(((Control)materialTextBox1).get_Text()))
			{
				MessageBox.Show("Invalid Username. usernames cannot contain any special characters.");
				return;
			}
			if (string.IsNullOrEmpty(((Control)materialTextBox2).get_Text()) || ((Control)materialTextBox1).get_Text().Length < 3)
			{
				MessageBox.Show("Username cannot be empty or below 3 characters.", "Error", (MessageBoxButtons)0, (MessageBoxIcon)16);
				return;
			}
			try
			{
				if (!IsValidPath(((Control)materialTextBox2).get_Text()))
				{
					MessageBox.Show("Invalid Fortnite path.", "Error", (MessageBoxButtons)0, (MessageBoxIcon)16);
					return;
				}
			}
			catch
			{
				MessageBox.Show("Invalid Fortnite path.", "Error", (MessageBoxButtons)0, (MessageBoxIcon)16);
				return;
			}
			string text = Path.Combine(((Control)materialTextBox2).get_Text(), "FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping.exe");
			if (!File.Exists(text))
			{
				MessageBox.Show("\"FortniteClient-Win64-Shipping.exe\" was not found, please make sure it exists.", "Error", (MessageBoxButtons)0, (MessageBoxIcon)16);
				return;
			}
			Settings.Default.Username = ((Control)materialTextBox1).get_Text();
			Settings.Default.Path = ((Control)materialTextBox2).get_Text();
			((SettingsBase)Settings.Default).Save();
			string text2 = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "Platanium.dll");
			if (!File.Exists(text2))
			{
				MessageBox.Show("\"Platanium.dll\" was not found, please make sure it exists.", "Error", (MessageBoxButtons)0, (MessageBoxIcon)16);
				return;
			}
			string text3 = "-AUTH_LOGIN=\"" + ((Control)materialTextBox1).get_Text() + "@unused.com\" -AUTH_PASSWORD=unused -AUTH_TYPE=epic";
			_clientAnticheat = 2;
			if (_clientAnticheat == 0)
			{
				text3 += " -epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -noeac -nobe -fltoken=none";
			}
			else if (_clientAnticheat == 1)
			{
				text3 += " -epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -noeac -fromfl=be -fltoken=f7b9gah4h5380d10f721dd6a";
			}
			else if (_clientAnticheat == 2)
			{
				text3 += " -epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -noeac -nobe -fltoken=8c4aa8a9b77acdcbd918874b";
			}
			Process val2 = new Process();
			ProcessStartInfo val3 = new ProcessStartInfo(text, text3);
			val3.set_UseShellExecute(false);
			val3.set_RedirectStandardOutput(true);
			val3.set_CreateNoWindow(false);
			val2.set_StartInfo((ProcessStartInfo)(object)val3);
			_clientProcess = (Process)(object)val2;
			Process val4 = (Process)(object)new Process();
			string fileName = Path.Combine(((Control)materialTextBox2).get_Text(), "FortniteGame\\Binaries\\Win64\\FortniteLauncher.exe");
			val4.get_StartInfo().set_FileName(fileName);
			val4.Start();
			foreach (ProcessThread item in (ReadOnlyCollectionBase)val4.get_Threads())
			{
				ProcessThread val5 = (ProcessThread)(object)item;
				Win32.SuspendThread(Win32.OpenThread(2, bInheritHandle: false, val5.get_Id()));
			}
			Process val6 = (Process)(object)new Process();
			string fileName2 = Path.Combine(((Control)materialTextBox2).get_Text(), "FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping_EAC.exe");
			val6.get_StartInfo().set_FileName(fileName2);
			val6.get_StartInfo().set_Arguments("-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -noeac -nobe -fltoken=8c4aa8a9b77acdcbd918874b");
			val6.Start();
			foreach (ProcessThread item2 in (ReadOnlyCollectionBase)val6.get_Threads())
			{
				ProcessThread val7 = (ProcessThread)(object)item2;
				Win32.SuspendThread(Win32.OpenThread(2, bInheritHandle: false, val7.get_Id()));
			}
			_clientProcess.Start();
			if (num != 0)
			{
				Console.WriteLine("Invalid Argument!");
				Console.ReadKey();
				return;
			}
			val.SetValue("ProxyEnable", (object)0);
			val.SetValue("ProxyServer", (object)0);
			if ((int)val.GetValue("ProxyEnable", (object)1) != 1)
			{
				Console.WriteLine("The proxy has been turned off.");
			}
			else
			{
				Console.WriteLine("Unable to disable the proxy.");
			}
			val.Close();
			InternetSetOption(IntPtr.Zero, 39, IntPtr.Zero, 0);
			InternetSetOption(IntPtr.Zero, 37, IntPtr.Zero, 0);
			IntPtr hProcess = Win32.OpenProcess(1082, bInheritHandle: false, _clientProcess.get_Id());
			IntPtr procAddress = Win32.GetProcAddress(Win32.GetModuleHandle("kernel32.dll"), "LoadLibraryA");
			uint num2 = (uint)((text2.Length + 1) * Marshal.SizeOf(typeof(char)));
			IntPtr intPtr = Win32.VirtualAllocEx(hProcess, IntPtr.Zero, num2, 12288u, 4u);
			Win32.WriteProcessMemory(hProcess, intPtr, Encoding.Default.GetBytes(text2), num2, out UIntPtr _);
			Win32.CreateRemoteThread(hProcess, IntPtr.Zero, 0u, procAddress, intPtr, 0u, IntPtr.Zero);
		}

		private void materialButton3_Click_1(object sender, EventArgs e)
		{
			Process.Start("https://discord.gg/DJ6VUmD");
		}

		private void materialButton4_Click(object sender, EventArgs e)
		{
			Form val = (Form)(object)new Browser();
		}
	}
}
