using System;
using System.IO;

internal class AsyncStreamReader
{
	public delegate void EventHandler<Args>(object sender, string value);

	private StreamReader _reader;

	protected readonly byte[] _buffer;

	public bool Active
	{
		get;
		private set;
	}

	public event EventHandler<string> ValueRecieved;

	public AsyncStreamReader(StreamReader reader)
	{
		_reader = reader;
		_buffer = new byte[4096];
		Active = false;
	}

	protected void Begin()
	{
		if (Active)
		{
			_reader.BaseStream.BeginRead(_buffer, 0, _buffer.Length, new AsyncCallback(Read), null);
		}
	}

	private void Read(IAsyncResult result)
	{
		if (_reader != null)
		{
			int num = _reader.BaseStream.EndRead(result);
			string value = null;
			if (num <= 0)
			{
				Active = false;
			}
			else
			{
				value = _reader.CurrentEncoding.GetString(_buffer, 0, num);
			}
			this.ValueRecieved?.Invoke(this, value);
			Begin();
		}
	}

	public void Start()
	{
		if (!Active)
		{
			Active = true;
			Begin();
		}
	}

	public void Stop()
	{
		Active = false;
	}
}
